<?php
	include('connect.php');
	session_start();
	
	if(isset($_SESSION['username'])){
		header("Location: login.php");
		return;
	}
	if (isset($_POST['post']) && isset($_POST['title']) && isset($_POST['content'])){
		$title = strip_tags($_POST['title']);
		$content = strip_tags($_POST['content']);/*

		$title = mysqli_real_escape_string($conn, $title);
		$content = mysqli_real_escape_string($conn, $content);
*/
		$sql = "INSERT into blog (title, content) values ('$title', '$content')";
		$insert = mysqli_query($conn,$sql);

		if($sql){
			echo"success";
		}else{
			echo"unsuccessful";
		}

		if($title == "" || $content == "") {
			echo "Please complete your post!";
			return;
		}
		mysqli_query($conn, $insert);

		header("Location:index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Blog - Post</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>
<body>
		<form action="addpost.php" method="post" enctype="multipart/form-data">
			<input placeholder="Title" name="title" id = "title" type="text" autofocus size="48"><br/><br/>
			<textarea placeholder="Content" name="content" id="content" rows="20" cols="50"></textarea><br/>
			<button type="submit" name="post" id="post">POST</button> 
			<!--?php
					if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['post'])){
						$title = $_POST['title'];
						$content = $_POST['content'];

						$query = "INSERT into blog (title, content) values ('$title', '$content')";
						$insert = mysqli_query($conn,$query);				
					}
			?-->
		</form>
</body>
</html>