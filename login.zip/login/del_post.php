<?php
	session_start();
	include_once("connect.php");

	if($_SESSION['username'] == true){
		header("Location: login.php");
		return;
	}
	if(!isset($_GET['id'])){
		header("Location: index.php");
	}else{
		$pid = $_GET['id'];
		$sql = "DELETE from blog where id=$pid";
		mysqli_query($conn,$sql);
		if(!mysqli_query($conn, $sql)){
			echo "ERROR!";
		}else{
		header("Location: index.php");
		}
	}
	?>