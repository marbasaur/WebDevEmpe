<?php
	include('connect.php');
	session_start();

	if(isset($_SESSION['username'])){
		header("Location: login.php");
		return;
	}
	if(!isset($_GET['id'])){
		header("Location: index.php");
	}

	$pid = $_GET['id'];

	if (isset($_POST['update']) && isset($_POST['title']) && isset($_POST['content'])){
		$title = strip_tags($_POST['title']);
		$content = strip_tags($_POST['content']);/*

		$title = mysqli_real_escape_string($conn, $title);
		$content = mysqli_real_escape_string($conn, $content);
*/

		if(isset($_POST['edit'])){
			$pid = $_POST['edit'];

		$date = date('l jS \of F Y h:i:s A');

		$sql = "UPDATE blog SET title='$title', content='$content', date='$date' WHERE id=$pid";
		$insert = mysqli_query($conn,$sql);
}
		if($sql){
			echo"success";
		}else{
			echo"unsuccessful";
		}

		if($title == "" || $content == "") {
			echo "Please complete your post!";
			return;
		}
		mysqli_query($conn, $insert);

		header("Location:index.php");
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Blog - Post</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"
	  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	  crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</head>
<body>
<form method="POST">

	<?php
	
		$pid = $_GET['id'];
		$sql_get = "SELECT * from blog Where id = $pid";
		$res = mysqli_query($conn,$sql_get);

		if(mysqli_num_rows($res) > 0) {
			while ($row = mysqli_fetch_assoc($res)){
				$title = $row['title'];
				$content = $row['content'];
				$id = $row['id'];

				echo "<form action='edit_post.php?pid=$pid' method='post' enctype='multipart/form-data'>";
				echo "<input placeholder='Title' name='title' id = 'title' type='text' value='$title' autofocus size='8'><br/><br/>";
				echo "<textarea placeholder='Content' name='content' id='content' rows='20' cols='50'>$content</textarea><br/>"; 
				echo "<button type='button' data-toggle='modal' data-target='#update'>Update</button>";
				echo "<input type='hidden' id='bid' name='bid' value='$id'>";
			}
		}
	
	?>
		
			<!--?php
					if(isset($_POST['title']) && isset($_POST['content']) && isset($_POST['post'])){
						$title = $_POST['title'];
						$content = $_POST['content'];

						$query = "INSERT into blog (title, content) values ('$title', '$content')";
						$insert = mysqli_query($conn,$query);				
					}
			?-->

			<div class="modal fade" id="update" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Update Blog</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="close">
								<span aria-hidden="True">&times;</span>
							</button>
				
						</div >
						<div class="modal-body">Are you Sure you want to edit?</div>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary" id="confirmupdate" name="confirmupdate">Yes</button>
							<?php
								if (isset($_POST['title']) && isset($_POST['content']) && isset($_POST['confirmupdate']) && isset($_POST['bid'])){

									$title=$_POST['title'];
									$content=$_POST['content'];
									$id = $_POST['bid'];

									$sql = "UPDATE blog SET title='$title', content='$content' WHERE id=$id";
									$insert = mysqli_query($conn,$sql);
									if ($insert){
										header('Location:/login/index.php');
									}
								}
							?>

							<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
						</div>
					</div>
				</div>
			</div>
		</form>

</body>
</html>