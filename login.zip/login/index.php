<?php
	include('connect.php');
	session_start();

	if(session_id()){
	echo $_SESSION['username'];
	}
	else {
	header("Location: login.php");
		
	}

?>	

	

<!DOCTYPE html>
<html>
	<head>
		<title>Blog</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="./css/index.css">
		<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
	</head>
	<script type="text/javascript">
		function edit(p){
			var id = p;
			window.location = 'edit_post.php?id='+id;
		}
	</script>
	<body>
		<?php
			require_once("nbbc/nbbc.php");

			$bbcode = new BBCode;

			$sql = "SELECT * from blog Order by id DESC";
			$res = mysqli_query($conn, $sql) or die (mysqli_error());

			$posts = "";

			if(mysqli_num_rows($res) > 0) {
				while($row = mysqli_fetch_assoc($res)){
					$title = $row['title'];
					$content = $row['content'];
					$date = $row['date'];

					echo "<div class='container'>";
						echo "<div class='row'>";
							echo "<div class='sticky'>";
							echo "</div>";
						echo "</div>";
						echo "<div class='row'>";
							echo "<div class='posts col-sm-12'>";
								echo "<h2>" .$row['title']. "</h2>";
								echo "<p>" .$row['content']. "</p>";
								echo "<p>" .$row['date']. "</p>";
								echo "<button class='btn btn-primary' onclick='edit(" . $row['id'] .")' id='pid'>Edit</button>&nbsp;";
								echo "<button class='btn btn-default' data-toggle='modal' data-target='#delete" . $row['id']. "' >Delete</button>"; 
							echo "</div>";
						echo "</div>";
					echo "</div>";

					?>
			<div class="modal fade" id="delete<?php echo $row['id'];?>" tabindex="-1" role="dialog">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title">Delete Blog</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="close">
								<span aria-hidden="True">&times;</span>
							</button>
				
						</div >
						<div class="modal-body">Are you Sure you want to delete post <?php echo $row['title'];?></div>
						<div class="modal-footer">
							<a href="del_post.php?id=<?php echo $row['id']?>"><button class="btn btn-success">Yes</button></a>
							<button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
						</div>
					</div>
				</div>
			</div>
			<?php
				}
				echo $posts;
			} else {
				echo "There are no posts to display.";
			}
		?>

	</body>
	<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</html>