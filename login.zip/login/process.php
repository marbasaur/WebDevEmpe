<?php
	include('connect.php');
	$username = $_POST['user'];
	$password = $_POST['pass'];

	$username = stripcslashes($username);
	$password = stripcslashes($password);
	$username = mysql_real_escape_string($username);
	$password = mysql_real_escape_string($password);

	mysql_connect("localhost", "root", "");
	mysql_select_db("login");

	$result = mysql_query("Select * from user where  username = '$username' and password = '$password'") or die("Failed to query database".mysql.error());
	$row = mysql_fetch_array($result);
	if ($row['username'] == $username && $row['password'] == $password){
		echo "Login success!!! Welcome ".$row['username'];
	} else {
		header("Location: login.php");
		// echo "Failed to login!";
	}
	?>

<!DOCTYPE html>
<html>
<head>
	<title>
		Add
	</title>
</head>
<body>
<form method = "POST">
<button type="submit" formaction = "/login/addpost.php" > Add Post </button>
</form>
</body>
</html>